import React from 'react'
import './Header.css'

const Header = () => {
  return (
    <div className='header'>
        <div className="header-contents">
          
            <h2>Order your favourite food here</h2>
            <p>"Satisfy your cravings with just a tap!"</p>
            
        </div>
    </div>
  )
}

export default Header