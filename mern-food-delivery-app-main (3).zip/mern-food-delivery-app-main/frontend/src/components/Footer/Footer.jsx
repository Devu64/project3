import React from 'react'
import './Footer.css'
import { assets } from '../../assets/assets'

const Footer = () => {
  return (
    <div className='footer' id='footer'>
        <div className="footer-content">
            <div className="footer-content-left">
                <h2>CRAVE KART</h2>
                {/* <img src={assets.logo} alt="" /> */}
                <p>Food you love, delivered with care.
Quick, easy, and always satisfying.
Because great meals are just a tap away.

</p>
               
            </div>
           
            <div className="footer-content-right">
                <h2>GET IN TOUCH</h2>
                <ul>
                    <li>+94 0123456789</li>
                    <li>cravekart@gmail.com</li>
                </ul>
            </div>
           
        </div>
        <hr />
        
    </div>
  )
}

export default Footer